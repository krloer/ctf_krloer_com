import os
import base64
import pickle
from flask import Flask, render_template, request

app = Flask(__name__)
app.secret_key = os.urandom(16)

class Postcard():
  def __init__(self, text, background, stamp):
    self.text = text
    self.background = background
    self.stamp = stamp

  def __repr__(self):
    return f"{self.text}"

default_postcard = Postcard("Hello Mr. Pickle<br /><br />Pickles are cool right?","1","1")

def serialize(text, background, stamp):
  postcard = Postcard(text, background, stamp)
  return postcard, base64.b64encode(pickle.dumps(postcard))

def deserialize(serialized):
  postcard = pickle.loads(base64.b64decode(serialized))
  return postcard

@app.errorhandler(404)
@app.errorhandler(500)
def error_handler(e):
  return render_template('index.html', error="Oops! There was something wrong in loading/saving the pickle postcard.", postcard=default_postcard, data="")

@app.route('/', methods=['GET', 'POST'])
def index():
  data = str(request.args.get("data", ""))

  # Load/Deserialize postcard data
  if request.method == "GET" and data:
    
    deserialized_postcard = deserialize(data)

    return render_template('index.html', error="", postcard=deserialized_postcard, data=data)
  
  # Save/Serialize postcard data
  if request.method == "POST":
    text = str(request.form["text"])
    background = str(request.form["background"])
    stamp = str(request.form["stamp"])

    postcard, serialized_data = serialize(text, background, stamp)
    
    return render_template('index.html', error="", postcard=postcard, data=serialized_data.decode())
  
  return render_template('index.html', error="", postcard=default_postcard, data="")

if __name__ == "__main__":
  app.run()