// Postcard elements
const text = document.querySelector(".postcard > p");
const background = document.querySelector(".postcard");
const stamp = document.querySelector(".postcard > img");

// Inputs
const inputText = document.querySelector("#text");
inputText.addEventListener("keydown", function () {
	text.innerHTML = this.value;
});
inputText.addEventListener("change", function () {
	text.innerHTML = this.value;
});
const inputBackground = document.querySelector("#background");
inputBackground.addEventListener("change", function () {
	background.style.backgroundImage = `url(${BACKGROUNDS[+this.value]})`;
});
const inputStamp = document.querySelector("#stamp");
inputStamp.addEventListener("change", function () {
	stamp.src = STAMPS[+this.value];
});

// First init
text.innerHTML = inputText.value;
background.style.backgroundImage = `url(${
	BACKGROUNDS[+inputBackground.value]
})`;
stamp.src = STAMPS[+inputStamp.value];
